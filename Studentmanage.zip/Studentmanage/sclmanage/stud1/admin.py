from django.contrib import admin

from .models import SclModel


admin.site.register(SclModel)