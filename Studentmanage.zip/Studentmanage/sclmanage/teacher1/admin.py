from django.contrib import admin


from .models import TeachModel


admin.site.register(TeachModel)