print('hello')
# Python Variables
x = 5
y = "Ram"
print(x)
print(y)

a = 6
a = "Smruti"  # a is type str
print(a)

# Python Casting
x = float(5)
y = int(3)
z = str("Sita")
print(x)
print(y)
print(z)

# Python Type
a = 8
b = "Home"
print(type(a))
print(type(b))


