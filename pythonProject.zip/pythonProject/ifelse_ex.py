# a = 'start'
# b = 'start'
# if a == b:
#     print('the process started')
# print('the process in progress')
# elif a == 'start:
#    print('the process is in else block')
# print('the process is outside of if')
# c = 5
# d = False
# if a == b and d:
#    if c == 5:
#        print('c is good')
#     else:
#        print('c is not good')
# else:
#     print('a is not b')

# elif

a = '5'
b = '5'
if a == b:
    print('the process started')
    print('the process in progress')
elif a == 'start':
    print('the process is in else block')
print('the process is outside of if')

