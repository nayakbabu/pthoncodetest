# Nested if
a = True
b = 5
if a:
    print("a is true")
    if b == 5:
        print("b exists")
    else:
        print("b doesnt exist")
else:
    print("a is false")
# if-else Example

num = 10
if num > 0:
    print('Positive number')
else:
    print('Negative number')

num = -6
if num > 0:
    print('Positive number')
else:
    print('Negative number')

# if-elif example

a = 140
b = 140
if b > a:
    print('b is greater than a')
elif a == b:
    print('a and b are equal')
else:
    print('a is greater than b')
