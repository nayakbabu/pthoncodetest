i = 10
if i == 10:
    if i < 15:
        print('i is smaller than 15')
    if i < 12:
        print('i is smaller than 12 too')
    else:
        print('i is greater than 15')

i = 20
if i == 10:
    print('i is 10')
elif i == 15:
    print('i is 15')
elif i == 20:
    print('i is 20')
else:
    print('i is not present')