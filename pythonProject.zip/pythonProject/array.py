my_array = ['Ram', 'Gita', 'Sita', 'Smruti']
# print(my_array)
# x = my_array[2]
# print(x)
# for x in my_array:
#     print(x)
# # Append
# my_array.append("Hari")
# print(my_array)
print(len(my_array))
my_array = my_array + ['Ramesh']
print(my_array)
