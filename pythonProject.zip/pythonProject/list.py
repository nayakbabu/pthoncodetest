my_list = [1, 2, 3, 4, 5]
for x in my_list:
    print(x)

fruit_list = ["apple", "banana", "cherry", "orange", "mango", "jackfruit"]
print(fruit_list[2:4])
print(fruit_list[1:5:3])
# Tuples
my_tuple = ("apple", "banana", "mango", "orange")
print(my_tuple[2:4])
my_tuple2 = (1, 2, 3, 4, 5, "apple", "mango", "kiwi")
print(my_tuple2[-3:-2])
