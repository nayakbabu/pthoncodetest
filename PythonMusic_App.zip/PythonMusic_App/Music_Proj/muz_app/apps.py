from django.apps import AppConfig


class MuzAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'muz_app'
