query = ['starbucks cupertino', 'McDonalds', 42, 'apple park', 'park ave', 'cupertino ca', 'Mcdonalds', 'mcdonalds',
         'Starbucks', 'starbucks', 'cupertino Ca', 'starbucks ca', 'starbucks Ca', 'mcdonalds SF', 'apple park',
         'park ave', 'cupertino ca', 'starbucks Cupertino', 'mcdonalds', 'Apple park', 'park ave', 'cupertino ca',
         'starbucks cupertino', 'mcdonalds', 'mcdonalds', 'Starbucks', 'apple park', 'park ave', 'cupertino ca']

print("Count of the each queries in the list are: ")
for char in range(0, len(query)):
    count = 1
    for x in range(char+1, len(query)):
        if query[char] == query[x] and query[char] != '':
            count = count + 1
    if count > 1 and query[char] != '0':
        print(query[char], ":", count)



