query = ['starbucks cupertino', 'McDonalds', '42', 'apple park', 'park ave', 'cupertino ca', 'Mcdonalds', 'mcdonalds',
         'Starbucks', 'starbucks', 'cupertino Ca', 'starbucks ca', 'starbucks Ca', 'mcdonalds SF', 'apple park',
         'park ave', 'cupertino ca', 'starbucks Cupertino', 'mcdonalds', 'Apple park', 'park ave', 'cupertino ca',
         'starbucks cupertino', 'mcdonalds', 'mcdonalds', 'Starbucks', 'apple park', 'park ave', 'cupertino ca']

# Remove whitespace from each strings
charter = []
for i in query:
    charter.append(i.replace(' ', ''))
print(charter)
